const GetSingleTodo = (todo_id) => {
    return fetch(`http://localhost:3333/list/${todo_id}`)
    .then((response) => {
        if(response.status === 200){
            return response.json()
        }else{
            throw 'Something went wrong'
        }
    })
    .then((resJson) => {
        return resJson
    })
    .catch((err) => {
        console.log("Err",err)
        return Promise.reject(err)
    })
}


const GetAllTodo = () => {
    return fetch(`http://localhost:3333/list/`)
      .then((response) => {
        if(response.status === 200){
            return response.json()
        }else{
            throw 'Something went wrong'
        }
    })
    .then((resJson) => {
        return resJson
    })
    .catch((err) => {
        console.log("Err", err)
        return Promise.reject(err)
    })
}


const createTodo = (todo_title,todo_description, deadline) => {
    return fetch(`http://localhost:3333/create`, {
        method: 'POST',
        headers: {
            "Content-Type": "application/json",
        },
        body: JSON.stringify({
            "todo_title": todo_title,
            "todo_description": todo_description,
            "deadline": deadline
        })
    })
    .then((response)=> {
        if(response.status === 201){
            return response.json()
        }else if(response.status === 400){
            throw "Bad request"
        }else {
            throw "Something went wrong"
        }
    })
    .then((resJson) => {
        return resJson
    })
    .catch((err) => {
        console.log("Err", err)
        return Promise.reject(err)
    })
}

export const coreService = {
    GetSingleTodo,
    GetAllTodo,
    createTodo,
}