<template>
    <div class="form">
        <form @submit.prevent="handleSubmit">
            <label for="title">Todo Title</label>
            <input type="text" name="title" v-model="title"/>
            <div v-show="submitted && !title">Title is required</div>
            
            <label for="description">Todo description</label>
            <input type="text" name="description" v-model="description"/>
            <div v-show="submitted && !description">Description is required</div>

            <label for="deadline">Deadline</label>
            <input type="number" name="deadline" v-model="deadline"/>
            <div v-show="submitted && !deadline">Deadline is required</div>


            <button>Send Todo</button>
            <div v-if="error">{{ error }}</div>

        </form>
    </div>
    </template>

    <script>

import { coreService } from "../services/core.service"

        export default {
            data(){
                return{
                    title: "",
                    description: "",
                    deadline: 0,
                    submitted: false,
                    error: ""
                }
            },
            methods: {
                handleSubmit(e){
                    this.submitted = true
                    this.error = ""

                    const {title,description,deadline} = this;
                    if((!title || !description || !deadline)){
                        return;
                    }

                    coreService.createTodo(title,description,deadline)
                    .then(result => {
                        console.log("Successfully created item")
                    })
                    .catch(error => {
                        console.error("Item creation failed:", error)
                    })
                }
            }
        }
    </script>
    <style>

        form{
            display: flex;
            flex-direction: column;
            width: 50%;
            line-height: 20px;
            padding: 12px;
        }

        label{
            margin-bottom: 6px;
        }
        input{
            margin-bottom: 8px;
        }
    </style>