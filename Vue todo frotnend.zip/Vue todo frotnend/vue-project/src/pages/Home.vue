<template>
    <div class ="notepad-content">
    <h1> To-Do List</h1>

    <em v-if="loading">Loading Items...</em>

    <ul v-if="todo.length">
        <li v-for="item in todo" :key="item.todo_id">
            {{ item.todo_title +  " " + item.todo_description + " " + item.deadline }}
        </li>
    </ul>

    <div v-if="error">
        {{ error }}
    </div>
    </div>
    </template>

    <script>

        import { coreService } from "../services/core.service"

        export default {
            data(){
                return {
                    todo: [],
                    error: "",
                    loading: true
                }
            },
            mounted(){
                coreService.GetAllTodo()
                .then(todo => {
                    this.todo = todo
                    this.loading = false
                })
                .catch(error => this.error = error)
            }
        }
    </script>
    <style>
        .notepad-content {
    font-family: "Courier New"; 
    font-size: 16px;                         
    line-height: 30px;                       
    padding-top: 10px;                        
    padding-right: 10px;                     
}


.notepad-content ul {
    list-style: none;     
}

.notepad-content h1 {
    font-size: 22px;
}
    </style>