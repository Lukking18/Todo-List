import {createRouter, createWebHistory} from 'vue-router';

import Home from "../pages/Home.vue"
import CreateTodo from '../pages/CreateTodo.vue';



const routes = [

    {path: "/", component : Home },
    {path: "/create", component: CreateTodo }
]

const router = createRouter({
    history: createWebHistory(),
    routes,
})

export default router;