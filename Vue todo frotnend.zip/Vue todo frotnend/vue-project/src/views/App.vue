<template>



<div class ="app-wrapper">
    <div class = "notepad">
<nav>


    
<router-link to="/">Home </router-link>

<router-link to="/create">Create Todo </router-link>

</nav>
<router-view />


</div>
</div>
    </template>

<style>
.app-wrapper{ 
    height: 100vh;
    display: flex;
    background: linear-gradient(rgb(16, 93, 121), rgb(7, 50, 66));
    justify-content: center;
    align-items: flex-start;
    padding: 40px 20px;

}

.notepad{
    position: relative;
    height: 89vh;
    width: 60vw;
 background: linear-gradient(#ffffff 29px, #d9dde0 30px);
 background-size: 100% 30px;
 box-shadow: 0px 10px 30px  rgb(0,0,15);
 padding-left: 90px;
}

.notepad::before {
    content: "";
    position: absolute;
    height: 100%;
    left: 55px;
    border-left: 2px solid red;
}

.notepad nav {
    display:flex;
    justify-content: space-evenly;
    gap: 40px;
}
</style>