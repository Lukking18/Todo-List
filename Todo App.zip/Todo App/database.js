const sqlite3 = require('sqlite3').verbose();

const DBSOURCE = 'db.sqlite';

let db = new sqlite3.Database(DBSOURCE, (err) => {
    if(err){
        console.log(err.message);
        throw err;
    }else{
        console.log('Connected to the SQLite database.')


        db.run(`CREATE TABLE todo ( 
            todo_id INTEGER PRIMARY KEY AUTOINCREMENT,
            todo_title text,
            todo_description text,
            deadline INTEGER
        )`, (err) => {
            if(err){
                console.log('todo table already created');
            } else {
                console.log('todo table created');
            }
        }
    )}
 });

module.exports = db;
