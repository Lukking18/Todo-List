const db = require('../../database');
const nodemon = require('nodemon');

const create_todo = (todo, done) => {
    const sql = "INSERT INTO todo (todo_title, todo_description, deadline) VALUES (?,?,?)";
    let values = [todo.todo_title, todo.todo_description, todo.deadline]

    db.run(sql, values, function(err){
        if(err) return done(err);
        return done(null, this.lastID)
    });
}

const get_single_item = (todo_id, done) => {
    const sql = "SELECT * FROM todo WHERE todo_id = ?";

    db.get(sql,[todo_id],(err,row) => {
        if(err){ return done(err);
        }if(!row){
            return done(null,null)
        } else{
            return done (null,row);
        }
    });
}

const get_all_lists = (done) => {
    const sql = "SELECT * FROM todo";

    db.all(sql, (err,row) => {
        if(err){ return done(err);
        }
        return done (null,row);
        
    });
}



module.exports = {

    create_todo,
    get_single_item,
    get_all_lists,
};