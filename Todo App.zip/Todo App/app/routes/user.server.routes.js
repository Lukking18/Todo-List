const users = require("../controllers/user.server.controllers")

module.exports = function(app){

    app.route("/create")
    .post(users.create_todo);

    app.route("/list/:list_id")
    .get(users.get_single_list);

    app.route("/list")
    .get(users.get_all_lists);


}
