const userModel = require("../models/user.server.models");
const Joi = require("joi");


const create_todo = (req, res) => {
    const schema = Joi.object({
      todo_title: Joi.string().required(),
      todo_description: Joi.string().required(),
      deadline: Joi.number().greater(0).required()
    });
    const { error } = schema.validate(req.body);
    if (error) return res.status(400).json({ error_message: error.details[0].message});

    userModel.create_todo(req.body, (err,todo_id) => {
        if(err){
            return res.status(500).json({error_message: "Internal Server Error"});
        }
        return res.status(201).json({todo_id});
    });
};

const get_all_lists = (req, res) => {
    userModel.get_all_lists((err, row) => {
        if(err){
            return res.status(500).json({ error_message: "Internal Server Error" });
        } else if(!row){
            return res.status(404).json({ error_message: "Items not found" });
        }
        return res.status(200).json(row);
    });
}


const get_single_list = (req, res) => {
    userModel.get_single_item(req.params.todo_id, (err, row) => {
        if(err){
            return res.status(500).json({error_message: "Internal Server Error"});
        } if(!row){
            return res.status(404).json({error_message: "Item not found"});
        }
        return res.status(200).json(row);
    });
};


module.exports = {
    create_todo: create_todo,
    get_single_list: get_single_list,
    get_all_lists: get_all_lists
};